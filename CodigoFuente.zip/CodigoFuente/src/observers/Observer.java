package observers;

public interface Observer {
	public void actualizar();
}
