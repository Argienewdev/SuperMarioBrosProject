package visitors;

public interface Visitado {
	
	public void aceptarVisitante(Visitante visitante);
	
}
