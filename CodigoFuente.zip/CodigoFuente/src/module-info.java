/**
 * 
 */
/**
 * 
 */
module superMario {
	exports elementos;
	exports fabricas;
	exports fuentes;
	exports generadores;
	exports imagenes;
	exports juego;
	exports launcher;
	exports observers;
	exports ventanas;
	exports visitors;
	exports elementos.enemigos;
	exports elementos.powerUps;
	exports elementos.personajes;
	exports elementos.plataformas;
	exports elementos.entidades;
	exports sonido.sonidoModoAlternativo;
	exports sonido.sonidoModoOriginal;
	requires java.desktop;
}
