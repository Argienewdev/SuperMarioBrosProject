package ventanas;

public interface Observer {

}
